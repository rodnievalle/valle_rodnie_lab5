package com.example.splitthebill;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {
    double tipss=.18;
    int bill;
    double doubletips;
    int groupnumber;
    double total;
    double groupshares;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        final EditText billenter= (EditText) findViewById(R.id.enterbill);
        final EditText groupenter= (EditText) findViewById(R.id.entergroup);
        Button splitbutton = (Button) findViewById(R.id.split);
       splitbutton.setOnClickListener(new View.OnClickListener() {
            TextView splitresult = (TextView) findViewById(R.id.result);
            @Override
            public void onClick(View v) {
                bill = Integer.parseInt(billenter.getText().toString());
                groupnumber = Integer.parseInt(groupenter.getText().toString());
                doubletips = tipss * bill;
                total = bill + doubletips;
                groupshares = total / groupnumber;
                DecimalFormat currency = new DecimalFormat( "Php###,###.##");
                splitresult.setText("Your tips is " + currency.format(doubletips) + " \n " +
                        "Group shares is " + currency.format(groupshares));


            }
        });
    }
}



